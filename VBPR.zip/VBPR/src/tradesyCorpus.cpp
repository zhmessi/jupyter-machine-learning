#include "tradesyCorpus.hpp"

void tradesyCorpus::loadData(const char* userDataPath, const char* featurePath, int userMin, int itemMin)
{
	nUsers = 0;
	nItems = 0;
	nVotes = 0;

	imFeatureDim = 4096;

	loadUserData(userDataPath, userMin);
	loadFeatures(featurePath);

	fprintf(stderr, "\n  \"nUsers\": %d, \"nItems\": %d, \"nVotes\": %d\n", nUsers, nItems, nVotes);
}

void tradesyCorpus::loadFeatures(const char* imgFeatPath)
{
	for (int i = 0; i < nItems; i ++) {
		vector<pair<int, float> > vec;
		imageFeatures.push_back(vec);
	}

	FILE* f = fopen_(imgFeatPath, "rb");
	fprintf(stderr, "\n  Loading image features from %s ", imgFeatPath);

	float ma = 32.671101; // Largest feature observed
	float* feat = new float [imFeatureDim];
	char* asin = new char [11];
	asin[10] = '\0';
	int a;
	int counter = 0;
	while (!feof(f)) {
		if ((a = fread(asin, sizeof(*asin), 10, f)) != 10) {
			//printf("Expected to read %d chars, got %d. LineNo = %d\n", 10, a, count);
			continue;
		}

		// trim right space
		string itemUID(asin);
		size_t found = itemUID.find(" ");
		if (found != string::npos) {
			itemUID = itemUID.substr(0, found);
		}
		for (unsigned c = 0; c < itemUID.size(); c ++) {
			if (not isascii(itemUID[c])) {
				printf("Expected asin to be 10-digit ascii\n");
				exit(1);
			}
		}
		
		if ((a = fread(feat, sizeof(*feat), imFeatureDim, f)) != imFeatureDim) {
			printf("Expected to read %d floats, got %d\n", imFeatureDim, a);
			exit(1);
		}

		// discard items not in scope
		if (itemIds.find(itemUID) == itemIds.end()) {
			continue;
		}

		vector<pair<int, float> > &vec = imageFeatures.at(itemIds[itemUID]);
		for (int f = 0; f < imFeatureDim; f ++) {
			if (feat[f] != 0) {  // compression
				vec.push_back(std::make_pair(f, feat[f]/ma));
			}
		}

		// print process
		if (not ((++ counter) % 10000)) {
			fprintf(stderr, ".");
			fflush(stderr);
		}
	}
	fclose(f);
	fprintf(stderr, "\n");

	delete [] asin;
	delete [] feat;
}

void tradesyCorpus::loadUserData(const char* userFilePath, int userMin)
{
	nUsers = 0;
	nItems = 0;

	igzstream in;
	in.open(userFilePath);
	if (! in.good()) {
		fprintf(stderr, "Can't read votes from %s.\n", userFilePath);
		exit(1);
	}
	fprintf(stderr, "\n  Loading user data from %s, userMin = %d ", userFilePath, userMin);

	string currentUID;
	string itemUID;
	vector<string> pos_items;
	string line;
	unsigned long lineNo = 0;
	while (getline(in, line)) {
		lineNo ++;
		stringstream lineStream(line);
		switch (lineNo % 5) {
			case 1:
				if (! (lineStream >> currentUID)) {
					printf("User UID read error! Line # %lu.", lineNo);
					exit(1);
				}
				pos_items.resize(0);

				// print process
				if (not (nUsers % 10000)) {
					fprintf(stderr, ".");
					fflush(stderr);
				}
				continue;

			case 4: // bought list
				while (lineStream >> itemUID) {
					pos_items.push_back(itemUID);
				}
				break;

			case 0: // want list
				while (lineStream >> itemUID) {
					pos_items.push_back(itemUID);
				}

				// check if discard/add a user
				if (pos_items.size() >= (unsigned)userMin) {
					// add the user
					rUserIds[nUsers] = currentUID;
					userIds[currentUID] = nUsers ++;

					// add the votes
					for (vector<string>::iterator it = pos_items.begin(); it != pos_items.end(); it ++) {
						itemUID = *it;

						// new item
						if (itemIds.find(itemUID) == itemIds.end()) {
							rItemIds[nItems] = itemUID;
							itemIds[itemUID] = nItems ++;
						}

						vote* v = new vote();
						v->user = userIds[currentUID];
						v->item = itemIds[itemUID];
						v->label = 1; // positive
						V.push_back(v);
					}
				}
				break;

			default:
				continue;
		}
	}
	in.close();

	nVotes = V.size();
	random_shuffle(V.begin(), V.end());
}
