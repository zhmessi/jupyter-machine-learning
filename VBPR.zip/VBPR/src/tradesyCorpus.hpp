#pragma once

#include "corpus.hpp"

class tradesyCorpus : public corpus
{
public:
	tradesyCorpus() {}
	~tradesyCorpus() {}

	void loadData(const char* userDataPath, const char* featurePath, int userMin, int itemMin);

private:
	void loadFeatures(const char* imgFeaturePath);
	void loadUserData(const char* userFilePath, int userMin);
};
